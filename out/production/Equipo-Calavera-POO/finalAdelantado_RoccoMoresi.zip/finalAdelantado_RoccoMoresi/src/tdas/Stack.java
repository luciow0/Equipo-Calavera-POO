package tdas;

public interface Stack {
    int getTop();
    void remove();
    boolean isEmpty();
    void add(int value);
}
