package tdas;

public interface Set {
    void add(int a);
    int choose();
    void remove(int a);
    boolean isEmpty();
}
